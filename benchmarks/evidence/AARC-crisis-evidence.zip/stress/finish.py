import time,json,subprocess,sys
from pathlib import Path
root=Path('benchmark-runs/stress')
deadline=time.monotonic()+1800
while True:
 failures=[root/f'failures-{i}.json' for i in [0,1]]
 if all(p.exists() for p in failures):
  errors=[e for p in failures for e in json.loads(p.read_text())]
  if errors:raise RuntimeError(errors)
  if len(list((root/'cases').glob('*.json')))==356:break
 if time.monotonic()>deadline:raise TimeoutError('Replay did not finish')
 time.sleep(5)
for module in ['backend.stress_ablation','backend.stress_report','backend.stress_verify','backend.stress_export']:
 print('Running',module,flush=True)
 subprocess.run([sys.executable,'-m',module],check=True)
print('ALL_REPORTS_COMPLETE',flush=True)
