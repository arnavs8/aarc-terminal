const {chromium}=require(require('path').resolve('../browser-tools/node_modules/playwright-core'));
const path=require('path');
(async()=>{
const browser=await chromium.launch({channel:'msedge',headless:true});
const page=await browser.newPage({viewport:{width:1400,height:1100}});
const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.goto('http://localhost:3003/stress-test');
await page.getByRole('heading',{name:'What happens when markets break?'}).waitFor();
const results=[];
for(const episode of ['covid','hikes'])for(const market of ['us','india']){
 await page.getByLabel('Episode',{exact:true}).selectOption(episode);
 await page.getByLabel('Market',{exact:true}).selectOption(market);
 await page.waitForFunction(({episode,market})=>{
  const s=document.querySelector('select[aria-label="Recorded decision"]');
  return s&&s.options.length>0&&s.value.startsWith(episode+'-')&&(s.value.includes('.NS-')===(market==='india'));
 },{episode,market});
 const select=page.getByLabel('Recorded decision',{exact:true});
 const count=await select.locator('option').count();
 await select.selectOption({index:count-1});
 results.push({episode,market,cases:count});
}
await page.getByLabel('Episode',{exact:true}).selectOption('covid');
await page.getByLabel('Market',{exact:true}).selectOption('us');
await page.getByLabel('Show original',{exact:true}).check();
await page.screenshot({path:path.resolve('../../outputs/AARC-crisis-dashboard.png')});
await page.setViewportSize({width:390,height:844});
await page.screenshot({path:path.resolve('../../outputs/AARC-crisis-mobile.png')});
if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+2))throw Error('Mobile horizontal overflow');
await page.goto(require('url').pathToFileURL(path.resolve('../../outputs/AARC-crisis-benchmark.html')).href);
await page.waitForFunction(()=>document.querySelector('#status').textContent.startsWith('356 completed cases embedded'));
const count=await page.locator('#case option').count();if(count!==356)throw Error('Offline case count');
await page.locator('#case').selectOption({index:355});
await page.setViewportSize({width:1400,height:1000});
await page.screenshot({path:path.resolve('../../outputs/AARC-offline-report.png')});
if(errors.length)throw Error(JSON.stringify(errors));
console.log(JSON.stringify({online:results,offlineCases:count,browserErrors:errors,mobileOverflow:false}));
await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
