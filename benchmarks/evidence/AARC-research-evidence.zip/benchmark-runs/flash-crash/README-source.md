---
license: mit
tags:
- finance
pretty_name: SPY ETF High-frequency data
size_categories:
- 10M<n<100M
---
# Dataset Card for SPY ETF High-frequency data

This dataset was created by aggregating message-level observations for the ETF SPY which tracks the S&P 500 index. We retrieved and evaluate the entire available
order book message history for the first 50 levels from July 1st 2007 to October 31st 2025. We restrict our analysis to order book activity during regular trading hours. 

## Dataset Details

### Dataset Description

We aggregate the
order book messages into the following variables, measured at 5 second intervals:

1. Initiator net volume (in million USD) which is the net of buyer and seller
initiated shares transacted during the last 5-minute interval. We sign transactions
as +1 if executed against a sell-side limit order and -1 if executed
against a buy-side limit order. For execution against a hidden limit order,
we impose the sign +1 if the transaction executes at a price that exceeds
the last observed midquote and -1 if the transaction price is below the last observed midquote.
1. Trading volume (in million USD), which is the cumulative trading volume
during each 5-second interval. We compute trading volume as the number
of traded shares times the transaction price.
1. Bid-ask spread (in basis points), computed as the time-weighted average
difference between the best prices quoted at the sell and buy side of the
order book during each 5-second interval. We compute the bid-ask spread
relative to the current midquote for every order book snapshot.
1. Depth measured as the number of posted shares in visible
limit orders 5 basis points from the current best price on both sides of the
order book. We take the time-weighted average depth during each interval
to aggregate depth from message level into 5-second intervals.


- **Curated by:** Stefan Voigt (stefan.voigt@econ.ku.dk)
- **License:** MIT

### Dataset Sources

More information on the dataset can be found in the paper "Market responses to a VIX shock" by Albert J. Menkveld, Nikolaus Hautsch, and Stefan Voigt. 

- **Repository:** [https://github.com/voigtstefan/market-responses-to-a-vix-shock](https://github.com/voigtstefan/market-responses-to-a-vix-shock)

## Citation 

Please cite the paper "Market responses to a VIX shock" by Albert J. Menkveld, Nikolaus Hautsch, and Stefan Voigt when using our dataset.

**BibTeX:** 

    @unpublished{menkveld2026vix,
      author = {Menkveld, Albert J. and Hautsch, Nikolaus and Voigt, Stefan},
      title  = {Market Responses to a {VIX} Shock},
      note   = {Available at SSRN: \url{https://ssrn.com/abstract=6298780}},
      url    = {https://ssrn.com/abstract=6298780},
      year   = {2026},
      month  = feb,
      day    = {24},
    }

