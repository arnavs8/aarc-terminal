import os
import asyncio
import json
from pathlib import Path
from typing import Optional, Dict, Any, List
from dotenv import load_dotenv

# Ensure .env is loaded before anything else
ROOT_ENV_PATH = Path(__file__).resolve().parent.parent / ".env"
load_dotenv(dotenv_path=ROOT_ENV_PATH, override=True)
from fastapi import FastAPI, Query, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sse_starlette.sse import EventSourceResponse

from backend.graph import stream_committee, run_cro_node, run_bull_node, run_bear_node
from backend.tools.quant_math import analyze_ticker_quant
from backend.tools.sentiment_nlp import analyze_ticker_sentiment
from backend.calibration.bayesian_calibrator import BetaBinomialConfidenceCalibrator
import yfinance as yf

app = FastAPI(
    title="Autonomous Adversarial Risk Committee (AARC) API",
    description="Institutional Dark-Mode Multi-Agent Risk Committee Backend",
    version="1.0.0"
)


@app.get('/api/portfolio/recommendation')
async def portfolio_recommendation():
    """Paper allocation from the frozen training policy; never submits orders."""
    def calculate():
        import pandas as pd
        from backend.portfolio_research import targets
        root=Path(__file__).resolve().parent.parent
        policy=json.loads((root/'benchmarks/strategy/frozen-policy.json').read_text())['selected']
        frames={}
        for symbol in ('SPY','QQQ','TLT','GLD'):
            frame=yf.download(symbol,period='2y',auto_adjust=False,actions=True,progress=False,threads=False)
            if isinstance(frame.columns,pd.MultiIndex):frame.columns=frame.columns.get_level_values(0)
            if len(frame)<253:raise ValueError('Insufficient price history')
            # Exclude today's potentially incomplete bar, using exchange-local date.
            index=pd.DatetimeIndex(frame.index).tz_localize(None)
            frame.index=index
            frames[symbol]=frame.loc[index<pd.Timestamp.now(tz='America/New_York').tz_localize(None).normalize()]
        as_of=min(f.index[-1] for f in frames.values())
        weights=targets({s:f.loc[:as_of] for s,f in frames.items()},policy['lookback'],policy['risk_target'])
        return {'as_of':str(as_of.date()),'weights':weights,'cash_weight':max(0.,1-sum(weights.values())),'policy':policy,'mode':'paper_only','execution':'Monthly allocation planner; trade no earlier than next session open. This endpoint places no orders.','scope':'Separate USD ETF portfolio; not single-stock committee or a guaranteed 10% return.'}
    try:return await asyncio.to_thread(calculate)
    except Exception as exc:raise HTTPException(status_code=503,detail='Portfolio inputs unavailable: '+type(exc).__name__)

# Enable CORS for frontend requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get('/api/research/forecast')
async def research_forecast(ticker: str = Query(default='AAPL', max_length=25)):
    """Live Timestral research scenario, explicitly separate from the production CRO."""
    import re
    clean = ticker.strip().upper()
    if not re.fullmatch(r'[A-Z0-9][A-Z0-9.\-]{0,24}', clean):
        raise HTTPException(status_code=400, detail='Use an equity ticker such as AAPL or RELIANCE.NS')
    def run():
        import pandas as pd
        from backend.models.timestral_forecast import forecast_batch, decide
        frame = yf.download(clean, period='2y', auto_adjust=False, progress=False, threads=False)
        if isinstance(frame.columns, pd.MultiIndex):
            frame.columns = frame.columns.get_level_values(0)
        frame.index = pd.DatetimeIndex(frame.index).tz_localize(None)
        forecast = forecast_batch([frame.Close.to_numpy()[-252:]])[0]
        return {'ticker': clean, 'forecast': forecast, 'decision': decide(frame, forecast),
                'production_enabled': False, 'scope': 'Experimental five-session scenario; not the production committee verdict or an order.'}
    try:
        return await asyncio.to_thread(run)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f'Research forecast unavailable: {type(exc).__name__}') from exc

CACHE_FILE = Path(__file__).resolve().parent / "demo_cache.json"


def load_demo_cache() -> Dict[str, Any]:
    if CACHE_FILE.exists():
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"[CACHE] Error reading demo cache: {e}")
    return {}


def save_to_demo_cache(key: str, events: List[Dict[str, Any]]):
    try:
        cache = load_demo_cache()
        cache[key] = events
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(cache, f, indent=2)
        print(f"[CACHE] Saved successful run for key '{key}' to {CACHE_FILE}")
    except Exception as e:
        print(f"[CACHE] Error saving to demo cache: {e}")


@app.get("/health")
@app.get("/")
async def health_check():
    return {
        "status": "healthy",
        "service": "Autonomous Adversarial Risk Committee (AARC)"
    }


TICKER_ALIASES = {
    "ZOMATO": "ETERNAL.NS",
    "ZOMATO.NS": "ETERNAL.NS",
    "ZOMATO.BO": "ETERNAL.BO",
}


@app.get("/api/instrument")
async def instrument_name(ticker: str = Query(min_length=1, max_length=32)):
    """Resolve only an exact symbol match; never assign a different company's name."""
    symbol = ticker.strip().upper()
    if symbol in ("ZOMATO", "ZOMATO.NS"):
        return {"ticker": "ETERNAL.NS", "name": "Eternal Limited (formerly Zomato)"}
    elif symbol == "ETERNAL.NS":
        return {"ticker": "ETERNAL.NS", "name": "Eternal Limited (formerly Zomato)"}
    try:
        search = await asyncio.to_thread(yf.Search, symbol, max_results=10, news_count=0)
        for quote in search.quotes:
            if str(quote.get("symbol", "")).upper() == symbol:
                name = quote.get("longname") or quote.get("shortname")
                if name:
                    return {"ticker": symbol, "name": name}
    except Exception as exc:
        print(f"[INSTRUMENT] Lookup failed for {symbol}: {exc}")
    return {"ticker": symbol, "name": None}


@app.get("/api/instruments/search")
async def search_instruments(q: str = Query(min_length=1, max_length=80)):
    """Search company names and symbols, returning only equity listings."""
    query = q.strip()
    if not query:
        return {"results": []}
    try:
        search = await asyncio.to_thread(yf.Search, query, max_results=20, news_count=0)
        results = []
        seen = set()

        if "zomato" in query.lower() or "eternal" in query.lower():
            results.append({
                "ticker": "ETERNAL.NS",
                "name": "Eternal Limited (formerly Zomato)",
                "exchange": "NSE"
            })
            seen.add("ETERNAL.NS")
        for quote in search.quotes:
            if quote.get("quoteType", "").upper() != "EQUITY":
                continue
            symbol = quote.get("symbol")
            name = quote.get("longname") or quote.get("shortname")
            if not isinstance(symbol, str) or not isinstance(name, str) or not symbol or not name:
                continue
            symbol = symbol.upper()
            if symbol in seen:
                continue
            seen.add(symbol)
            results.append({"ticker": symbol, "name": name, "exchange": quote.get("exchDisp") or quote.get("exchange") or ""})
            if len(results) == 8:
                break
        return {"results": results}
    except Exception as exc:
        print(f"[INSTRUMENT] Search failed: {exc}")
        raise HTTPException(status_code=503, detail="Stock search is temporarily unavailable") from exc


@app.get("/api/stream")
async def stream_committee_endpoint(
    ticker: str = Query(default="RELIANCE.NS", description="Asset ticker symbol"),
    cutoff_date: Optional[str] = Query(default=None, description="Optional historical cutoff date (YYYY-MM-DD) for backtesting")
):
    """
    SSE endpoint that streams node completion events:
    quant -> news -> bull -> bear -> cro
    as `data: <json>\\n\\n`.
    Failures are reported explicitly as `node: error` events; demo-cache replay is
    intentionally disabled so a request for one ticker can never be served another.
    """
    clean_t = ticker.strip().upper()
    clean_t = TICKER_ALIASES.get(clean_t, clean_t)
    cleaned_cutoff = cutoff_date.strip() if cutoff_date and cutoff_date.strip() else None
    cache_key = f"{clean_t}_{cleaned_cutoff or ''}"

    async def event_generator():
        recorded_events: List[Dict[str, Any]] = []

        try:
            async for node_event in stream_committee(ticker=clean_t, cutoff_date=cleaned_cutoff):
                recorded_events.append(node_event)
                yield {
                    "data": json.dumps(node_event, allow_nan=False)
                }

                # Do not replay cache after a failure: surface the error event and stop.
                if node_event.get("node") == "error":
                    return

            # Only persist a fully successful run; incomplete streams are reported as errors.
            if recorded_events and recorded_events[-1].get("node") == "index_complete":
                return
            if len(recorded_events) >= 5:
                save_to_demo_cache(cache_key, recorded_events)
            else:
                yield {
                    "data": json.dumps({
                        "node": "error",
                        "data": {
                            "stage": "stream",
                            "error": "Committee stream ended before all nodes completed",
                        },
                    })
                }

        except Exception as e:
            print(f"[STREAM] Execution failed or encountered error: {e}")
            yield {
                "data": json.dumps({"node": "error", "data": {"stage": "stream", "error": str(e)}})
            }

    return EventSourceResponse(event_generator())


class ConfidenceUpdateRequest(BaseModel):
    is_hit: bool = Field(description="Whether the previous risk or direction prediction was accurate")
    ticker: Optional[str] = Field(default=None, description="Optional asset ticker symbol")
    is_high_conf_divergence: bool = Field(default=False, description="Whether actual price movement breached thresholds despite high confidence (>=80%)")


@app.get("/api/regime/status")
async def get_regime_status(
    ticker: str = Query(default="RELIANCE.NS", description="Asset ticker symbol"),
    cutoff_date: Optional[str] = Query(default=None, description="Optional historical cutoff date (YYYY-MM-DD)"),
):
    """
    Exposes Gaussian HMM 3-state market regime classification and GARCH(1,1) volatility dynamics.
    Outputs active state probabilities, conditional volatility, and regime risk boundaries.
    """
    clean_t = ticker.strip().upper()
    clean_t = TICKER_ALIASES.get(clean_t, clean_t)
    try:
        quant_data = await asyncio.to_thread(analyze_ticker_quant, clean_t, cutoff_date)
        regime = quant_data.get("hmm_regime", {})
        return {
            "ticker": clean_t,
            "active_state": regime.get("active_state", 0),
            "regime_name": regime.get("regime_name", "LOW_VOL_TRENDING"),
            "probabilities": regime.get("probabilities", {"P_Trending": 0.65, "P_Panic": 0.10, "P_Choppy": 0.25}),
            "garch_vol_forecast_annual_pct": quant_data.get("garch_vol_forecast_pct"),
            "volatility_shock_ratio": quant_data.get("volatility_shock_ratio"),
            "regime_vol_annual_pct": regime.get("regime_vol_annual_pct"),
            "kelly_scale_factor": regime.get("kelly_scale_factor", 1.0),
            "stop_loss_multiplier": regime.get("stop_loss_multiplier", 1.0),
            "state_parameters": regime.get("state_parameters", {}),
            "current_price": quant_data.get("current_price"),
            "annualized_volatility": quant_data.get("annualized_volatility"),
            "daily_VaR_95_pct": quant_data.get("daily_VaR_95_pct"),
        }
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/anomaly/status")
async def get_anomaly_status(
    ticker: str = Query(default="RELIANCE.NS", description="Asset ticker symbol"),
    cutoff_date: Optional[str] = Query(default=None, description="Optional historical cutoff date (YYYY-MM-DD)"),
):
    """
    Exposes PyTorch LSTM Autoencoder sequence reconstruction anomaly detection
    alongside multi-timeframe ensemble Isolation Forest anomaly votes.
    """
    clean_t = ticker.strip().upper()
    clean_t = TICKER_ALIASES.get(clean_t, clean_t)
    try:
        quant_data = await asyncio.to_thread(analyze_ticker_quant, clean_t, cutoff_date)
        temporal = quant_data.get("temporal_anomaly", {})
        return {
            "ticker": clean_t,
            "is_temporal_anomaly": temporal.get("is_temporal_anomaly", False),
            "temporal_anomaly_score": temporal.get("temporal_anomaly_score", 0.0),
            "reconstruction_error": temporal.get("reconstruction_error", 0.0),
            "reconstruction_threshold": temporal.get("threshold", 0.0),
            "feature_breakdown": temporal.get("feature_breakdown", {}),
            "recent_10d_temporal_count": temporal.get("recent_10d_temporal_count", 0),
            "ensemble_isolation_forest": quant_data.get("anomaly_telemetry", {}),
            "point_in_time_anomalies_10d": quant_data.get("recent_10d_anomalies", 0),
        }
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/anomaly/stream")
async def stream_anomaly_status(
    ticker: str = Query(default="RELIANCE.NS", description="Asset ticker symbol"),
    cutoff_date: Optional[str] = Query(default=None, description="Optional historical cutoff date (YYYY-MM-DD)"),
):
    """
    Real-time SSE telemetry stream for temporal anomaly monitoring.
    """
    clean_t = ticker.strip().upper()
    clean_t = TICKER_ALIASES.get(clean_t, clean_t)

    async def anomaly_generator():
        try:
            quant_data = await asyncio.to_thread(analyze_ticker_quant, clean_t, cutoff_date)
            temporal = quant_data.get("temporal_anomaly", {})
            yield {
                "data": json.dumps({
                    "event": "anomaly_telemetry",
                    "ticker": clean_t,
                    "is_temporal_anomaly": temporal.get("is_temporal_anomaly", False),
                    "reconstruction_error": temporal.get("reconstruction_error", 0.0),
                    "threshold": temporal.get("threshold", 0.0),
                    "feature_breakdown": temporal.get("feature_breakdown", {}),
                    "recent_10d_temporal_count": temporal.get("recent_10d_temporal_count", 0),
                    "ensemble_isolation_forest": quant_data.get("anomaly_telemetry", {}),
                })
            }
        except Exception as exc:
            yield {
                "data": json.dumps({"event": "error", "error": str(exc)})
            }

    return EventSourceResponse(anomaly_generator())


@app.get("/api/sentiment/aspects")
async def get_sentiment_aspects(
    ticker: str = Query(default="RELIANCE.NS", description="Asset ticker symbol"),
    cutoff_date: Optional[str] = Query(default=None, description="Optional historical cutoff date (YYYY-MM-DD)"),
):
    """
    Exposes FinBERT sentiment analysis with Loughran-McDonald confidence thresholding,
    Aspect-Based Sentiment Analysis (Risk/Solvency, Liquidity/Cash Flow, Margin Health),
    and Tone Shift Index (TSI) narrative momentum.
    """
    clean_t = ticker.strip().upper()
    clean_t = TICKER_ALIASES.get(clean_t, clean_t)
    try:
        news_data = await asyncio.to_thread(analyze_ticker_sentiment, clean_t, cutoff_date)
        return {
            "ticker": clean_t,
            "aggregate_sentiment_score": news_data.get("aggregate_sentiment_score"),
            "ema_smoothed_sentiment": news_data.get("ema_smoothed_sentiment", news_data.get("aggregate_sentiment_score")),
            "aspect_scores": news_data.get("aspect_sentiment", {}),
            "composite_aspect_score": news_data.get("composite_aspect_score", 0.0),
            "tone_shift_index": news_data.get("tone_shift_index", 0.0),
            "tone_shift_regime": news_data.get("tone_shift_regime", "NEUTRAL"),
            "aspect_relevance": news_data.get("aspect_relevance", {}),
            "news_available": news_data.get("news_available", True),
            "news_error": news_data.get("news_error"),
            "sentiment_model": news_data.get("sentiment_model"),
            "interpretation_available": news_data.get("interpretation_available"),
            "evidence_review": news_data.get("evidence_review"),
            "headlines": news_data.get("headlines", []),
        }
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/risk/evaluate")
async def evaluate_risk_consolidated(
    ticker: str = Query(default="RELIANCE.NS", description="Asset ticker symbol"),
    cutoff_date: Optional[str] = Query(default=None, description="Optional historical cutoff date (YYYY-MM-DD)"),
):
    """
    Consolidated institutional risk arbitration endpoint:
    Synthesizes HMM dynamic regimes, GARCH(1,1) volatility forecasts, LSTM Autoencoder sequential anomalies,
    Aspect-Based Sentiment Analysis (ABSA), Tone Shift Index (TSI), and Chief Risk Officer (CRO) arbitration
    calibrated with Bayesian Beta-Binomial conjugate updating.
    """
    clean_t = ticker.strip().upper()
    clean_t = TICKER_ALIASES.get(clean_t, clean_t)
    try:
        quant_data = await asyncio.to_thread(analyze_ticker_quant, clean_t, cutoff_date)
        news_data = await asyncio.to_thread(analyze_ticker_sentiment, clean_t, cutoff_date)
        bull_thesis = await asyncio.to_thread(run_bull_node, quant_data, news_data)
        bear_thesis = await asyncio.to_thread(run_bear_node, quant_data, news_data, bull_thesis)
        cro_verdict = await asyncio.to_thread(run_cro_node, quant_data, news_data, bull_thesis, bear_thesis)

        return {
            "ticker": clean_t,
            "current_price": quant_data.get("current_price"),
            "action": cro_verdict.get("action"),
            "verdict": cro_verdict.get("verdict"),
            "calibrated_confidence": None,  # No fitted committee probability model yet.
            "heuristic_score": cro_verdict.get("confidence"),
            "confidence_kind": cro_verdict.get("confidence_kind"),
            "generation_mode": cro_verdict.get("generation_mode"),
            "evidence_audit": cro_verdict.get("evidence_audit"),
            "raw_confidence": cro_verdict.get("raw_confidence"),
            "bayesian_calibration": cro_verdict.get("bayesian_calibration"),
            "regime_gating": cro_verdict.get("regime_gating"),
            "temperature_scaling": cro_verdict.get("temperature_scaling"),
            "confidence_breakdown": cro_verdict.get("confidence_breakdown"),
            "brier_metrics": cro_verdict.get("brier_metrics"),
            "walk_forward_validation": cro_verdict.get("walk_forward_validation"),
            "tail_risk_grounding": cro_verdict.get("tail_risk_grounding"),
            "rolling_accuracy_telemetry": cro_verdict.get("rolling_accuracy_telemetry"),
            "regime": quant_data.get("hmm_regime"),
            "garch_volatility": {
                "5d_forecast_annual_pct": quant_data.get("garch_vol_forecast_pct"),
                "historical_annual_vol_pct": quant_data.get("annualized_volatility"),
                "volatility_shock_ratio": quant_data.get("volatility_shock_ratio"),
                "daily_VaR_95_pct": quant_data.get("daily_VaR_95_pct"),
                "expected_shortfall_95_pct": quant_data.get("expected_shortfall_95_pct"),
                "empirical_coverage_pct": quant_data.get("empirical_coverage_pct"),
                "var_breach_frequency_pct": quant_data.get("var_breach_frequency_pct"),
                "kupiec_pof_pvalue": quant_data.get("kupiec_pof_pvalue"),
            },
            "sequential_anomaly": quant_data.get("temporal_anomaly"),
            "ensemble_isolation_forest": quant_data.get("anomaly_telemetry"),
            "sentiment_and_tone_shift": {
                "aggregate_sentiment": news_data.get("aggregate_sentiment_score"),
                "aspects": news_data.get("aspect_sentiment"),
                "tone_shift_index": news_data.get("tone_shift_index"),
                "tone_shift_regime": news_data.get("tone_shift_regime"),
            },
            "risk_boundaries": {
                "recommended_allocation_pct": cro_verdict.get("recommended_allocation_pct"),
                "half_kelly_cap_pct": quant_data.get("half_kelly_allocation_pct"),
                "suggested_stop_loss_pct": cro_verdict.get("stop_loss_pct"),
                "kill_switch_reason": cro_verdict.get("kill_switch_reason"),
            },
            "theses": {
                "bull_thesis": bull_thesis,
                "bear_thesis": bear_thesis,
            },
            "verdict_summary": cro_verdict.get("verdict_summary"),
            "top_explainability_drivers": cro_verdict.get("top_drivers"),
        }
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/confidence/update")
async def update_bayesian_confidence(body: ConfidenceUpdateRequest = Body(...)):
    """
    Bayesian confidence updating endpoint:
    Increments alpha on successful risk/anomaly prediction and beta on false positives.
    If is_high_conf_divergence is flagged, applies an asymmetric evidence penalty.
    Updates the Beta-Binomial conjugate posterior moments and 90% credible intervals.
    """
    calibrator = BetaBinomialConfidenceCalibrator()
    summary = calibrator.update_evidence(
        is_hit=body.is_hit,
        ticker=body.ticker,
        is_high_conf_divergence=body.is_high_conf_divergence,
    )
    return {
        "status": "success",
        "ticker": body.ticker,
        "is_hit": body.is_hit,
        "is_high_conf_divergence": body.is_high_conf_divergence,
        "posterior_summary": summary,
    }


@app.get("/api/confidence/status")
async def get_confidence_status(ticker: Optional[str] = Query(default=None)):
    """
    Returns current Bayesian Beta-Binomial posterior accuracy, variance, and 90% credible intervals.
    """
    calibrator = BetaBinomialConfidenceCalibrator()
    summary = calibrator.get_posterior_summary(ticker=ticker)
    return {
        "ticker": ticker or "GLOBAL",
        "posterior_summary": summary,
    }


@app.get("/api/calibration/metrics")
async def get_calibration_metrics(
    ticker: Optional[str] = Query(default=None, description="Optional asset ticker symbol"),
):
    """
    Exposes rolling Brier Score loss, Brier Skill Score (BSS), Walk-Forward Validation
    out-of-sample metrics, and compound outcome statistics.
    """
    from backend.calibration.rolling_tracker import RollingAccuracyTracker
    tracker = RollingAccuracyTracker()
    clean_t = ticker.strip().upper() if ticker else None
    if clean_t:
        clean_t = TICKER_ALIASES.get(clean_t, clean_t)
    metrics = tracker.get_rolling_metrics_and_calibration_multiplier(clean_t)
    return {
        "ticker": clean_t or "GLOBAL",
        "metrics": metrics,
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
